import express from "express";
import mysql from "mysql2";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

// --- MySQL connection ---
const db = mysql.createConnection({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASS || "",
  database: process.env.DB_NAME || "festival_judging",
});


db.connect(err => {
  if (err) return console.error("❌ MySQL connection failed:", err);
  console.log("✅ MySQL connected.");
});

// --- Save or update score without duplicates ---
app.post("/api/scores", (req, res) => {
  const scoresArray = Array.isArray(req.body) ? req.body : [req.body];

  Promise.all(
    scoresArray.map(item =>
      new Promise((resolve, reject) => {
        const { contestant, criteria, score, category, judgeName } = item;

        // Check if score already exists for this judge & contestant & criteria
        const checkSql = `
          SELECT * FROM scores 
          WHERE judgeName = ? AND contestantNo = ? AND criteria = ?
        `;
        db.query(checkSql, [judgeName, contestant, criteria], (err, results) => {
          if (err) return reject(err);

          if (results.length > 0) {
            // Already exists, update the score
            const updateSql = `
              UPDATE scores
              SET score = ?, category = ?
              WHERE judgeName = ? AND contestantNo = ? AND criteria = ?
            `;
            db.query(
              updateSql,
              [Number(score), category, judgeName, contestant, criteria],
              (err2) => {
                if (err2) reject(err2);
                else resolve(true);
              }
            );
          } else {
            // Not exist, insert new
            const insertSql = `
              INSERT INTO scores (judgeName, contestantNo, criteria, score, category)
              VALUES (?, ?, ?, ?, ?)
            `;
            db.query(
              insertSql,
              [judgeName, contestant, criteria, Number(score), category],
              (err3) => {
                if (err3) reject(err3);
                else resolve(true);
              }
            );
          }
        });
      })
    )
  )
    .then(() => res.json({ message: "Score(s) saved" }))
    .catch(err => res.status(500).json({ error: "Database error", details: err }));
});

// --- Get scores by category with judge names ---
app.get("/api/scores", (req, res) => {
  const category = req.query.category || 0;
  db.query(
    "SELECT * FROM scores WHERE category = ?",
    [category],
    (err, results) => {
      if (err) return res.status(500).json({ error: "Database error" });

      const formatted = {};

      results.forEach(row => {
        if (!formatted[row.contestantNo]) {
          formatted[row.contestantNo] = { total: 0, scores: [] };
        }
        formatted[row.contestantNo].scores.push({
          criteria: row.criteria,
          score: row.score,
          judgeName: row.judgeName
        });
        formatted[row.contestantNo].total += row.score;
      });

      res.json(formatted);
    }
  );
});

// --- Add judge (prevent duplicate names) ---
app.post("/api/judges", (req, res) => {
  const { name } = req.body;
  if (!name) return res.status(400).json({ error: "Name required" });

  // Check if judge already exists
  db.query("SELECT * FROM judges WHERE name = ?", [name], (err, results) => {
    if (err) return res.status(500).json({ error: "Database error" });

    if (results.length > 0) {
      return res.status(400).json({ error: "Judge already exists" });
    }

    db.query("INSERT INTO judges (name) VALUES (?)", [name], (err2, result) => {
      if (err2) return res.status(500).json({ error: "Database error" });
      res.json({ id: result.insertId, name });
    });
  });
});

// --- Get all judges ---
app.get("/api/judges", (req, res) => {
  db.query("SELECT * FROM judges", (err, results) => {
    if (err) return res.status(500).json({ error: "Database error" });
    res.json(results);
  });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});


import path from "path";

// Serve React build
const __dirname = path.resolve(); // Needed for ES module
app.use(express.static(path.join(__dirname, "client/build"))); // assuming React app is in /client

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "client/build", "index.html"));
});
